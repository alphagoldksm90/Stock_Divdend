package com.dayone.model.constants;

public class CacheKey {
    public static final String KEY_FINANCE = "finance";
}
