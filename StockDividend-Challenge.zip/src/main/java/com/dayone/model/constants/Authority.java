package com.dayone.model.constants;

public enum Authority {

    ROLE_READ,
    ROLE_WRITE;
}
